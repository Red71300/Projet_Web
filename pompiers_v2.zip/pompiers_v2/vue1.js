//déplacement pompier sélectionné
$(function() {
	$(document).keydown(function(e) {
		//on vérifie qui des deux pompiers à une bordure
		var pompierSelectionne = "";
		if ($("#pompier1").css("border-style") == "solid")
		{
			pompierSelectionne="#pompier1";
			move(e,pompierSelectionne);
		}
		else if ($("#pompier2").css("border-style") == "solid")
		{
			pompierSelectionne="#pompier2";
			move(e,pompierSelectionne);
		}
	});
});

//déplacement pompier
function move(e, pompier)
{
	var x = parseInt($(pompier).css("left"));
	var y = parseInt($(pompier).css("top"));

	//mouvement gauche
	if (e.which == 39)
	{
		$(pompier).css("left", x+20);
	}
	//mouvement droit
	if (e.which == 37)
	{
		$(pompier).css("left", x-20);
	}
	//mouvement haut
	if (e.which == 38)
	{
		$(pompier).css("top", y-20);
	}
	//mouvement bas
	if (e.which == 40)
	{
		$(pompier).css("top", y+20);
	}
}


//clic sur un pompier
$("#pompier1").click(function() {
	//on annule d'abord la sélection de l'autre pompier
	$("#pompier2").css("border-style","none");

	//on sélectionne le pompier désiré
	$("#pompier1").css("border-style","solid");
	$("#pompier1").css("border-color","white");
});

$("#pompier2").click(function() {
	//on annule d'abord la sélection de l'autre pompier
	$("#pompier1").css("border-style","none");
	
	//on sélectionne le pompier désiré
	$("#pompier2").css("border-style","solid");
	$("#pompier2").css("border-color","white");
});


//instances de pompiers
class Pompier
{
	constructor(id)
	{
		this.id = id;
	}
}

pompier1 = new Pompier("1");
pompier2 = new Pompier("2");