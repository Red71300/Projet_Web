<html>
	<head>
		<meta charset = "utf-8" />
		<link rel = "stylesheet" type = "text/css" href = "vue1.css" />
	</head>
	
	<body>
		<p>Nombre d'entrées : <span>0</span></p>
		
		<div id = "scene">
			<img id="ville" src="pictures/ville.jpg">
			<img id="pompier1" src="pictures/pompier.png">
			<img id="pompier2" src="pictures/pompier.png">
			<img id="feu" src="pictures/feu.png">
		</div>

		<script src = "jQuery.js"></script>
		<script src = "vue1.js"></script>
	</body>
</html>