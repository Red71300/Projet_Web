<html>
	<head>
		<meta charset = "utf-8" />
		<link rel = "stylesheet" type = "text/css" href = "vue1.css" />
	</head>
	
	<body>
		<p>Nombre d'entrées : <span>0</span></p>
		
		<div id = "scene">
			<img id="ville" src="pictures/ville.jpg">
			<img id="pompier" src="pictures/pompier.png">
			<img id="feu" src="pictures/feu.png">
		</div>

		<script src = "client/jQuery.js"></script>
		<script src = "client/vue1.js"></script>
	</body>
</html>