$(function() {
	$(document).keydown(function(e) {
		var x = parseInt($("#pompier").css("left"));
		var y = parseInt($("#pompier").css("top"));

		//mouvement gauche
		if (e.which == 39)
		{
			$("#pompier").css("left", x+20);
		}
		//mouvement droit
		if (e.which == 37)
		{
			$("#pompier").css("left", x-20);
		}
		//mouvement haut
		if (e.which == 38)
		{
			$("#pompier").css("top", y-20);
		}
		//mouvement bas
		if (e.which == 40)
		{
			$("#pompier").css("top", y+20);
		}
	});
});