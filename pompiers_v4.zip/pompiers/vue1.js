//création des instances
var pompier1 = new Pompier("#pompier1");
var pompier2 = new Pompier("#pompier2");

//déplacement pompier sélectionné
$(function() {
	$(document).keydown(function(e) {
		//on vérifie qui des deux pompiers à une bordure
		if ($("#pompier1").css("border-style") == "solid")
		{
			move(e,pompier1);
		}
		else if ($("#pompier2").css("border-style") == "solid")
		{
			move(e,pompier2);
		}
	});
});

//déplacement pompier
function move(e, pompier)
{
	var x = parseInt($(pompier.id).css("left"));
	var y = parseInt($(pompier.id).css("top"));

	//mouvement gauche
	if (e.which == 39)
	{
		$(pompier.id).css("left", x+20);
	}
	//mouvement droit
	if (e.which == 37)
	{
		$(pompier.id).css("left", x-20);
	}
	//mouvement haut
	if (e.which == 38)
	{
		$(pompier.id).css("top", y-20);
	}
	//mouvement bas
	if (e.which == 40)
	{
		$(pompier.id).css("top", y+20);
	}
	//on vérifie si on est rentré dans la zone de danger
	checkZone(pompier);
}


//clic sur un pompier
$("#pompier1").click(function() {
	//on annule d'abord la sélection de l'autre pompier
	$("#pompier2").css("border-style","none");

	//on sélectionne le pompier désiré
	$("#pompier1").css("border-style","solid");
	//on ajuste la couleur en fonction de s'il porte quelque chose
	if ( pompier1.getPorte() == true ) {
		$("#pompier1").css("border-color","red");
	}	
	else
		$("#pompier1").css("border-color","white");
});

//clic sur l'autre pompier
$("#pompier2").click(function() {
	//on annule d'abord la sélection de l'autre pompier
	$("#pompier1").css("border-style","none");
	
	//on sélectionne le pompier désiré
	$("#pompier2").css("border-style","solid");
	//on ajuste la couleur en fonction de s'il porte quelque chose
	if ( pompier2.getPorte() == true )
		$("#pompier2").css("border-color","red");
	else
		$("#pompier2").css("border-color","white");
});

//vérification de pénétration dans la zone de danger
function checkZone(pompier)
{
	//alert(parseInt($(pompier.id).css("top")));
	//cas ou il se trouve dans la zone de danger
	if ( parseInt($(pompier.id).css("left")) >= 480 && parseInt($(pompier.id).css("left")) <= 620 && parseInt($(pompier.id).css("top")) >= 100 && parseInt($(pompier.id).css("top")) <= 300 ) {
		//si le pompier ne porte pas de victime
		if ( !pompier.getPorte() )
		{
			$(pompier.id).css("border-color","yellow"); //on le met en jaune --> il peut porter une victime
			//on porte une victime lors de l'appui sur espace
			$(document).keypress(function(event){
				var keycode = (event.keyCode ? event.keyCode : event.which);
				if(keycode == '32' && !pompier.getPorte() && $(pompier.id).css("border-color") == "rgb(255, 255, 0)" ) //pour ne pas que l'appui sur espace marche plusieurs fois sur la même instance de pompier et aussi pour que l'appui sur espace ne marche pas en dehors de la zone
				{
					porteVictime(pompier);
				}
			});
		}
	}
	//cas ou il se trouve dans la zone PMA
	else if ( parseInt($(pompier.id).css("left")) >= 20 && parseInt($(pompier.id).css("left")) <= 200 && parseInt($(pompier.id).css("top")) >= 480 && parseInt($(pompier.id).css("top")) <= 640 )
	{
		//si le pompier porte une victime
		if ( pompier.getPorte() )
		{
			$(pompier.id).css("border-color","blue"); //on le met en bleu --> il peut déposer une victime au PMA
			//on dépose une victime lors de l'appui sur espace
			$(document).keypress(function(event){
				var keycode = (event.keyCode ? event.keyCode : event.which);
				if(keycode == '32' && pompier.getPorte() && $(pompier.id).css("border-color") == "rgb(0, 0, 255)" ) //pour ne pas que l'appui sur espace marche plusieurs fois sur la même instance de pompier et aussi pour que l'appui sur espace ne marche pas en dehors de la zone
				{
					deposerVictime(pompier);
				}
			});
		}
	}
	//cas où le pompier se trouve dans le reste de la zone
	else 
	{
		//cas où le pompier ne porte rien, on met le contour en blanc
		if ( !pompier.getPorte() )
		{
			$(pompier.id).css("border-color","white");
		}
		//cas où le pompier porte une victime, on met le contour en rouge
		else if ( pompier.getPorte() )
		{
			$(pompier.id).css("border-color","red");
		}
	}
}

//porter une victime
function porteVictime(pompier)
{
	$(pompier.id).css("border-color","red");
	pompier.porterVictime();
	$("#totalVictimes").text(parseInt($("#totalVictimes").text())-1);
}

//deposer une victime
function deposerVictime(pompier)
{
	pompier.deposerVictime();
	$(pompier.id).css("border-color","white");
	$.ajax({
		type: 'POST',
		url: 'usageControllerVictime.php',
		data : {
			'nom' : generateString(5),
			'prenom' : generateString(5),
			'function' : 'insert'
		},
		timeout: 3000,
		success: function(response) 
		{
			console.log(response);
		},
		error: function(response) 
		{
			console.log("La requête n'a pas abouti"); 
			console.log(response);
		}
	});
}

//générer nom et prénom aléatoires
function generateString(length) 
{
	var result           = '';
	var characters       = 'abcdefghijklmnopqrstuvwxyz';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) 
	{
	   result += characters.charAt(Math.floor(Math.random() * charactersLength));
	}
	return result;
}

//insérer victime dans BDD
function insertVictime()
{
	$.ajax({
		type: 'POST',
		url: 'usageControllerVictime.php',
		data : {
			'nom' : generateString(5),
			'prenom' : generateString(5)
		},
		timeout: 3000,
		success: function(response) 
		{
		  console.log(response);
		},
		error: function(response) 
		{
		  console.log("La requête n'a pas abouti"); 
		  console.log(response);
		}
	});
}