<?php
    class ModelVictime extends Model
    {
        public function insertVictime($nom, $prenom)
        {
            $this->getBdd();
            $query = parent::$_bdd->prepare('INSERT INTO victime (NOM, PRENOM, VIVANT, VIE, CHARGE) VALUES (?, ?, 1, 100, 1);');
            $query->execute(array($nom, $prenom));
        }
    }
?>