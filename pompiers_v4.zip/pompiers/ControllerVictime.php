<?php
	class ControllerVictime
	{
		private $_model;
		private static $_instance;

		public function __construct()
		{
			$this->_model = new ModelVictime;
		}

		public function insertVictime($nom, $prenom)
		{
			$this->_model->insertVictime($nom, $prenom);
		}

		function test()
		{
			$text = "heyyy";
			echo $text;
		}

		public function showVue()
		{
			require_once("vue1.php");
		}

		public static function getInstance()
    	{
        	if(is_null(self::$_instance)) 
        	{
				self::$_instance = new ControllerVictime();
        	}
        	return self::$_instance;
    	}
	}
?>