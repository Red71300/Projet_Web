<?php
    require_once("Model.php");
    require_once("ModelVictime.php");
    require_once("ControllerVictime.php");
    if(isset($_POST['function']) && !empty($_POST['function']))
	{
		switch ($_POST['function']) 
		{
		    case 'insert':
                ControllerVictime::getInstance()->insertVictime($_POST['nom'], $_POST['prenom']);
            break;
		    default:
		        SendError("Fonction inexistante dans le switch");
            break;
		}
	}
?>