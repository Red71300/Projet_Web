class Pompier
{
	constructor(id)
	{
        this.id = id;
        this.porte = false;
	}

	porterVictime()
	{
		this.porte = true;
	}

	deposerVictime()
	{
		this.porte = false;
	}

	getPorte()
	{
		return this.porte;
	}
}